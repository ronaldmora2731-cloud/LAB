<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>Nuevo post</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content :fullscreen="true" class="ion-padding">
      <ion-button expand="block" fill="outline" @click="escanearQr" :disabled="escaneando">
        <ion-icon slot="start" :icon="qrCodeOutline" />
        {{ escaneando ? 'Abriendo cámara...' : 'Escanear QR con cámara' }}
      </ion-button>

      <ion-note class="ion-margin-top qr-ayuda">
        El QR debe contener usuario, título y texto. Ejemplo: {"usuario":1,"titulo":"Prueba","texto":"Hola"}.
      </ion-note>

      <ion-text v-if="mensajeQr" :color="errorQr ? 'danger' : 'success'">
        <p class="ion-padding-top">{{ mensajeQr }}</p>
      </ion-text>

      <form @submit.prevent="guardarPost">
        <ion-list>
          <ion-item>
            <ion-input
              label="Título"
              label-placement="floating"
              v-model="form.title"
              required
            />
          </ion-item>

          <ion-item>
            <ion-textarea
              label="Texto"
              label-placement="floating"
              v-model="form.body"
              :auto-grow="true"
              required
            />
          </ion-item>

          <ion-item>
            <ion-select
              label="Usuario"
              label-placement="floating"
              v-model="form.userId"
              placeholder="Seleccione un usuario"
              required
            >
              <ion-select-option
                v-for="usuario in usuarios"
                :key="usuario.id"
                :value="usuario.id"
              >
                {{ usuario.name }}
              </ion-select-option>
            </ion-select>
          </ion-item>
        </ion-list>

        <ion-button
          expand="block"
          type="submit"
          class="ion-margin-top"
          :disabled="guardando"
        >
          {{ guardando ? 'Guardando...' : 'Guardar' }}
        </ion-button>
      </form>

      <ion-card v-if="postCreado" class="ion-margin-top">
        <ion-card-header>
          <ion-card-title>Post creado</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <p><strong>ID:</strong> {{ postCreado.id }}</p>
          <p><strong>Título:</strong> {{ postCreado.title }}</p>
          <p><strong>Texto:</strong> {{ postCreado.body }}</p>
          <p><strong>Usuario:</strong> {{ postCreado.userId }}</p>
        </ion-card-content>
      </ion-card>
    </ion-content>
  </ion-page>
</template>

<script setup lang="ts">
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonInput,
  IonTextarea,
  IonSelect,
  IonSelectOption,
  IonButton,
  IonIcon,
  IonNote,
  IonText,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
} from '@ionic/vue';
import {
  CapacitorBarcodeScanner,
  Html5QrcodeSupportedFormats,
} from '@capacitor/barcode-scanner';
import { qrCodeOutline } from 'ionicons/icons';
import { reactive, ref } from 'vue';
import type { Posts } from '@/interfaces/posts';
import type { Usuarios } from '@/interfaces/usuarios';

const usuarios = ref<Usuarios[]>([]);
const guardando = ref(false);
const escaneando = ref(false);
const mensajeQr = ref('');
const errorQr = ref(false);
const postCreado = ref<Posts | null>(null);

const form = reactive({
  title: '',
  body: '',
  userId: null as number | null,
});

async function cargarUsuarios() {
  const response = await fetch('https://jsonplaceholder.typicode.com/users');
  usuarios.value = await response.json();
}

function buscarUsuario(valor: unknown) {
  if (valor === null || valor === undefined) return null;

  const id = Number(valor);
  if (Number.isInteger(id)) {
    const existe = usuarios.value.some((usuario) => usuario.id === id);
    if (existe) return id;
  }

  const texto = String(valor).trim().toLowerCase();
  const usuario = usuarios.value.find(
    (item) =>
      item.name.toLowerCase() === texto ||
      item.username.toLowerCase() === texto ||
      item.email.toLowerCase() === texto,
  );

  return usuario?.id ?? null;
}

function leerContenidoQr(contenido: string) {
  try {
    return JSON.parse(contenido) as Record<string, unknown>;
  } catch {
    const datos: Record<string, string> = {};

    contenido.split(/\r?\n|;/).forEach((linea) => {
      const separador = linea.search(/[:=]/);
      if (separador === -1) return;

      const clave = linea.slice(0, separador).trim();
      const valor = linea.slice(separador + 1).trim();
      if (clave) datos[clave] = valor;
    });

    return datos;
  }
}

function llenarFormularioDesdeQr(contenido: string) {
  const datos = leerContenidoQr(contenido);

  const titulo = datos.title ?? datos.titulo ?? datos['título'];
  const texto = datos.body ?? datos.texto;
  const usuario = datos.userId ?? datos.usuario ?? datos.user;

  if (!titulo || !texto || usuario === undefined) {
    throw new Error('El QR debe tener usuario, título y texto.');
  }

  const usuarioId = buscarUsuario(usuario);
  if (!usuarioId) {
    throw new Error('El usuario del QR no existe en la lista de usuarios.');
  }

  form.title = String(titulo);
  form.body = String(texto);
  form.userId = usuarioId;
}

async function escanearQr() {
  escaneando.value = true;
  mensajeQr.value = '';
  errorQr.value = false;

  try {
    const resultado = await CapacitorBarcodeScanner.scanBarcode({
      hint: Html5QrcodeSupportedFormats.QR_CODE,
      scanInstructions: 'Apunte la cámara al código QR',
      scanButton: false,
      web: {
        showCameraSelection: true,
      },
    });

    if (!resultado.ScanResult) return;

    llenarFormularioDesdeQr(resultado.ScanResult);
    mensajeQr.value = 'QR leído. Los campos se llenaron automáticamente.';
  } catch (error) {
    errorQr.value = true;
    mensajeQr.value =
      error instanceof Error ? error.message : 'No se pudo leer el código QR.';
  } finally {
    escaneando.value = false;
  }
}

async function guardarPost() {
  if (!form.title || !form.body || !form.userId) return;

  guardando.value = true;
  postCreado.value = null;

  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        title: form.title,
        body: form.body,
        userId: form.userId,
      }),
    });

    postCreado.value = await response.json();

    form.title = '';
    form.body = '';
    form.userId = null;
    mensajeQr.value = '';
  } finally {
    guardando.value = false;
  }
}

cargarUsuarios();
</script>

<style scoped>
.qr-ayuda {
  display: block;
}
</style>
